package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.fiap.conexao.Conexao;
import br.fiap.modelo.BilheteUnico;

public class BilheteUnicoDAO {
	private Connection connection;
	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;

	// método para verificar se um número de bilhete está na base dados
	public boolean pesquisarNumero(int numero) {
		connection = new Conexao().conectar();
		sql = "select * from java_bilhete where numero = ?";
		boolean aux = false;

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, numero);
			rs = ps.executeQuery();
			aux = rs.next();
		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar número do bilhete\n" + e);
		}

		return aux;
	}

	// método para inserir os dados do bilhete na base dados
	public void inserir(BilheteUnico bilhete) {
		connection = new Conexao().conectar();
		sql = "insert into java_bilhete(numero, cpf, saldo, valorPassagem) values(?, ?, ?, ?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, bilhete.getNumero());
			ps.setString(2, bilhete.getCpf());
			ps.setDouble(3, bilhete.getSaldo());
			ps.setDouble(4, bilhete.getValorPassagem());
			ps.execute(); // ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Erro ao inserir usuário pelo cpf\n" + e);
		}
	}

	// método para retornar os dados do bilhete cadastrado na base de dados
	public BilheteUnico pesquisarCpf(String cpf) {

		connection = new Conexao().conectar();
		sql = "select * from java_bilhete where cpf = ?";
		BilheteUnico bilhete = null;

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, cpf);
			rs = ps.executeQuery();
			if (rs.next()) {
				bilhete = new BilheteUnico(rs.getInt("NUMERO"), rs.getString("CPF"), rs.getDouble("SALDO"));
			}

		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar número do bilhete\n" + e);
		}

		return bilhete;

	}

}
