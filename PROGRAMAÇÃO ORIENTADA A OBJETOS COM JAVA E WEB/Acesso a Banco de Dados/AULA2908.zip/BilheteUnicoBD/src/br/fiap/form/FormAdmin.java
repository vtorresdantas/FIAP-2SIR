package br.fiap.form;

import static javax.swing.JOptionPane.*;

import br.fiap.dao.BilheteUnicoDAO;
import br.fiap.dao.UsuarioDAO;
import br.fiap.modelo.BilheteUnico;
import br.fiap.modelo.Usuario;

import static java.lang.Integer.parseInt;

public class FormAdmin {

	public void menuAdmin() {
		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenuAdmin()));
				switch (opcao) {
				case 1:
					emitirBilhete();
					break;
				case 3:
					consultar();
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A opção deve ser um número entre 1 e 4\n" + e);
			}
		} while (opcao != 4);

	}

	private void consultar() {
		BilheteUnicoDAO bilheteDao = new BilheteUnicoDAO();
		String cpf = showInputDialog("Digite o CPF do usuário");

		BilheteUnico bilhete = bilheteDao.pesquisarCpf(cpf);

		if (bilhete == null) {
			showMessageDialog(null, "CPF não está cadastrado");
		} else {
			
			showMessageDialog(null, bilhete.toString());
		}

	}

	private void emitirBilhete() {
		UsuarioDAO usuarioDao = new UsuarioDAO();
		BilheteUnicoDAO bilheteDao = new BilheteUnicoDAO();
		String cpf, nome, tipo;
		String[] opcao = { "Estudante", "Professor", "Normal" };

		cpf = showInputDialog("CPF do usuário");
		if (usuarioDao.pesquisarCpf(cpf)) {
			showMessageDialog(null, "CPF já tem um bilhete");
		} else {
			nome = showInputDialog("Nome do usuário");
			tipo = (String) showInputDialog(null, "Tipo de Tarifa", "Tipo de Tarifa", 0, null, opcao, opcao[0]);
			usuarioDao.inserir(new Usuario(nome, cpf, tipo));
			bilheteDao.inserir(new BilheteUnico(cpf));
		}

	}

	private String gerarMenuAdmin() {
		String menu = "Escolha uma operação:\n";
		menu += "1. Emitir Bilhete\n";
		menu += "2. Imprimir Bilhete\n";
		menu += "3. Consultar Bilhete\n";
		menu += "4. Sair";
		return menu;

	}

}
