package br.fiap.dao;

import static javax.swing.JOptionPane.showMessageDialog;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.fiap.conexao.Conexao;

public class UsuarioDAO {

	private Connection connection;
	private PreparedStatement ps;
	private ResultSet rs;
	private String sql;

	public boolean pesquisarCpf(String cpf) {
		connection = new Conexao().conectar();
		sql = "SELECT * FROM JAVA_USUARIO WHERE CPF = ?";
		boolean aux = false;

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, cpf);
			rs = ps.executeQuery();
			aux = rs.next();
		} catch (SQLException e) {

			showMessageDialog(null, "Erro ao consultar o cpf do usuário\n" + e);

		}

		return aux;
	}

}
