package br.fiap.bilhete;

public class BilheteUnico {
	
	private int numero;
	private String cpfUsuario;
	private double saldo;
	static private double valorPassagem = 4.40;

}
