package br.fiap.usuario;

public class Usuario {
	
	private String nome;
	private String cpf;
	private double tarifa; 

}
