package br.fiap.form;

import static javax.swing.JOptionPane.*;

import br.fiap.dao.UsuarioDAO;

import static java.lang.Integer.parseInt;

public class FormAdmin {

	public void menuAdmin() {
		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenuAdmin()));
				switch (opcao) {
				case 1:
					emitirBilhete();
					break;
				case 2:
					break;
				case 3:
					break;
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A opção deve ser um número entre 1 e 4\n" + e);
			}
		} while (opcao != 4);

	}

	private void emitirBilhete() {
		UsuarioDAO dao = new UsuarioDAO();
		String cpf, nome, tipo;
		String[] opcao = { "Estudante", "Professor", "Normal" };

		cpf = showInputDialog("CPF do usuário");
		if (dao.pesquisarCpf(cpf)) {
			showMessageDialog(null, "CPF já possuí um bilhete cadastrado");
		} else {
			nome = showInputDialog("Nome do usuário");
			tipo = (String) showInputDialog(null, "Tipo de tarifa", "Tipo de tarifa", 0, null, opcao, opcao[0]);

		}

	}

	private String gerarMenuAdmin() {
		String menu = "Escolha uma operação:\n";
		menu += "1. Emitir Bilhete\n";
		menu += "2. Imprimir Bilhete\n";
		menu += "3. Consultar Bilhete\n";
		menu += "4. Sair";
		return menu;

	}

}
