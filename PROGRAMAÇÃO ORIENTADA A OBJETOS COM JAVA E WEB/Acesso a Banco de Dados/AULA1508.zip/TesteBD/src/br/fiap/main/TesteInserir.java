package br.fiap.main;

import br.fiap.dao.FornecedorDAO;
import br.fiap.fornecedor.Fornecedor;

public class TesteInserir {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Fornecedor fornecedor = new Fornecedor(4, "teste");

		FornecedorDAO dao = new FornecedorDAO();
		dao.inserir(fornecedor);
		

	}

}
