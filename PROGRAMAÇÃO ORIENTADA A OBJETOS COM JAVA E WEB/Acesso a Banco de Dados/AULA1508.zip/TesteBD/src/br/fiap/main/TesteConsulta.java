package br.fiap.main;

import br.fiap.dao.FornecedorDAO;
import br.fiap.fornecedor.Fornecedor;

public class TesteConsulta {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		FornecedorDAO dao = new FornecedorDAO();
		System.out.println(dao.pesquisar(2));

	}

}
