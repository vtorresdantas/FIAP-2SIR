package br.fiap.main;

import br.fiap.dao.FornecedorDAO;

public class TesteListagem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FornecedorDAO dao = new FornecedorDAO();
		System.out.println(dao.listar());

	}

}
