package br.fiap.dao;

import static java.lang.Integer.parseInt;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.fornecedor.Fornecedor;

public class FornecedorDAO {

	// variáveis para manipulação de dados
	private Connection connection; // armazena a conexão com o banco de dados
	private PreparedStatement ps; // configura e executa o sql
	private ResultSet rs; // recebe os dados do banco
	private String sql; // escrever o comando SQL

	public FornecedorDAO() {
		connection = new Conexao().conectar();
	}

	public void inserir(Fornecedor fornecedor) {

		sql = "INSERT INTO JAVA_FORNECEDOR(id_fornecedor,nome) VALUES (?,?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, fornecedor.getId());
			ps.setString(2, fornecedor.getNome());
			ps.execute();

		} catch (SQLException e) {
			System.out.println("Erro ao inserir no banco de dados\n" + e);

		}
	}

	public boolean pesquisar(int id) {

		boolean aux = false;

		sql = "SELECT * FROM JAVA_FORNECEDOR WHERE id_fornecedor = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			aux = rs.next();

		} catch (SQLException e) {
			System.out.println("Erro ao consultar no banco de dados\n" + e);

		}

		return aux;
	}

	public List<Fornecedor> listar() {
		List<Fornecedor> lista = new ArrayList<Fornecedor>();


		sql = "SELECT * FROM JAVA_FORNECEDOR";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();

			while (rs.next()) {
				lista.add(new Fornecedor(rs.getInt("ID_FORNECEDOR"), rs.getString("NOME")));

			}

		} catch (SQLException e) {
			System.out.println("Erro ao listar no banco de dados\n" + e);

		}

		return lista;
	}
}
