package br.fiap.main;

import br.fiap.dao.FornecedorDAO;
import br.fiap.fornecedor.Fornecedor;

public class TesteInserir {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Fornecedor fornecedor = new Fornecedor(2, "vitor");

		FornecedorDAO dao = new FornecedorDAO();
		dao.consultar();

	}

}
