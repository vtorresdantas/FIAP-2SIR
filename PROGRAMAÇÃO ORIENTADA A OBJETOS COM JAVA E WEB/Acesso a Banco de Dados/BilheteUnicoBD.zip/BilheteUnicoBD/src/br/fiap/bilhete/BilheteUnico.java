package br.fiap.bilhete;

public class BilheteUnico {

	private int numero;
	private String cpfUsuario;
	private double saldo;
	private final double valorPassagem = 4.40;

	public BilheteUnico(String cpfUsuario) {
		super();
		this.cpfUsuario = cpfUsuario;
	}

	public void passarNaCatraca() {

	}

	public void carregar(double valor) {

	}

}
