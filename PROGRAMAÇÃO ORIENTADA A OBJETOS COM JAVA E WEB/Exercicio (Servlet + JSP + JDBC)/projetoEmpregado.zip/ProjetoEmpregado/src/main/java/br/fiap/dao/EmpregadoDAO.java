package br.fiap.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.modelo.entidade.Departamento;
import br.fiap.modelo.entidade.Empregado;

public class EmpregadoDAO extends DAO {

	// metodo para retonar os dados dos empregados

	public List<Empregado> listar() {

		List<Empregado> lista = new ArrayList<Empregado>();
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		Empregado empregado;
		Departamento departamento;

		sql = "select E.nome, E.cpf, D.nome as dnome from java_empregado E, "
				+ "java_departamento D where E.id_departamento = D.id";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				departamento = new Departamento();
				departamento.setNome(rs.getString("dnome"));
				empregado = new Empregado();
				empregado.setCpf(rs.getString("cpf"));
				empregado.setNome(rs.getString("nome"));
				empregado.setDepartamento(departamento);
				lista.add(empregado);
			}
			ps.close();
			conexao.desconectar();
		} catch (SQLException e) {
			System.out.println("Erro ao listar os dados\n" + e);
		}

		return lista;
	}

}
