package br.fiap.dao;

public class DepartamentoDAO extends DAO {

}
