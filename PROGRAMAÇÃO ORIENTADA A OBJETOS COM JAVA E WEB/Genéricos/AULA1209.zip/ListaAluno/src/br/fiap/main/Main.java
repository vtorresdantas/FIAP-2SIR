package br.fiap.main;

import br.fiap.aluno.Aluno;

public class Main {

	public static void main(String[] args) {

		Lista<Aluno> lista = new Lista<Aluno>();

		lista.inserir(new Aluno(88415, "Vitor"));
		lista.inserir(new Aluno(88430, "Matheus"));

		lista.imprimir();
	}

}
