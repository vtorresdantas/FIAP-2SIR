
public class Teste {

	public static void main(String[] args) {

		Integer[] x = { 1, 2, 3 };
		Double[] y = { 1.5, 2.5, 3.5 };
		String[] z = { "c#", "python", "java" };

		imprimir(x);
		System.out.println();
		imprimir(y);
		System.out.println();
		imprimir(z);

	}

	private static <T> void imprimir(T[] x) {
		for (T i : x) {
			System.out.println(i + "");
		}
	}

	/*
	 * private static void imprimir(String[] z) { for (String i : z) {
	 * System.out.println(i + ""); }
	 * 
	 * }
	 * 
	 * private static void imprimir(double[] y) { for (double i : y) {
	 * System.out.println(i + ""); } }
	 * 
	 * private static void imprimir(int[] x) { for (int i : x) {
	 * System.out.println(i + ""); } }
	 */

}
