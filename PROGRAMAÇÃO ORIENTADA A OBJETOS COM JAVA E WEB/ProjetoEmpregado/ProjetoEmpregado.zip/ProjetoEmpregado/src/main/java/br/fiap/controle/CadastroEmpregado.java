package br.fiap.controle;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.fiap.dao.conexao.EmpregadoDAO;
import br.fiap.modelo.entidade.Departamento;
import br.fiap.modelo.entidade.Empregado;

/**
 * Servlet implementation class CadastroEmpregado
 */
@WebServlet(name = "cadastro", urlPatterns = { "/cadastro" })
public class CadastroEmpregado extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CadastroEmpregado() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String nome = request.getParameter("nome");
		String cpf = request.getParameter("cpf");
		Integer id = Integer.parseInt(request.getParameter("departamento"));

		Departamento departamento = new Departamento();
		departamento.setId(id);

		Empregado empregado = new Empregado();

		empregado.setCpf(cpf);
		empregado.setNome(nome);
		empregado.setDepartamento(departamento);

		new EmpregadoDAO().cadastrar(empregado);

	}

}
