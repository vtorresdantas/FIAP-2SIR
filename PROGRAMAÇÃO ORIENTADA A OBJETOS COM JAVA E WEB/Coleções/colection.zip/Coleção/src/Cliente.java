import java.util.Objects;

public class Cliente {

	private Integer cpf;
	private String nome;

	public Cliente(Integer cpf, String nome) {
		super();
		this.cpf = cpf;
		this.nome = nome;
	}

	public String toString() {
		return "Cliente cpf = " + cpf + " nome = " + nome + "\n";
	}

	@Override
	public int hashCode() {
		return Objects.hash(cpf, nome);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cliente other = (Cliente) obj;
		return cpf == other.cpf && Objects.equals(nome, other.nome);
	}

	public Integer getCpf() {
		return cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setCpf(Integer cpf) {
		this.cpf = cpf;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
