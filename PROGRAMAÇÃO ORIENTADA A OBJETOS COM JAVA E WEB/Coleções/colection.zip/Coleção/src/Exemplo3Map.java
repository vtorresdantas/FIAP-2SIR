import java.util.HashMap;
import java.util.Map;

public class Exemplo3Map {
	public static void main(String[] args) {

		Map<Integer, Cliente> lista = new HashMap<>();

		Cliente c1 = new Cliente(2, "matheus");
		Cliente c2 = new Cliente(3, "jessica");
		Cliente c3 = new Cliente(4, "vitor");
		Cliente c4 = new Cliente(5, "alex");
		Cliente c5 = new Cliente(2, "matheus");

		lista.put(c1.getCpf(), c1);
		lista.put(c2.getCpf(), c2);
		lista.put(c3.getCpf(), c3);
		lista.put(c4.getCpf(), c4);
		lista.put(c5.getCpf(), c5);
		
		System.out.println(lista);
		
		System.out.println(lista.get(2));

	}
}
