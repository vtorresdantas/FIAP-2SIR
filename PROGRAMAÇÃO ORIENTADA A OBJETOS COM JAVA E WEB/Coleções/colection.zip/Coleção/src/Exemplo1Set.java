import java.util.HashSet;
import java.util.Set;

public class Exemplo1Set {

	public static void main(String[] args) {

		Set<Integer> lista = new HashSet<>();

		lista.add(15);
		lista.add(51);
		lista.add(150);
		lista.add(510);

		System.out.println(lista);

	}

}
