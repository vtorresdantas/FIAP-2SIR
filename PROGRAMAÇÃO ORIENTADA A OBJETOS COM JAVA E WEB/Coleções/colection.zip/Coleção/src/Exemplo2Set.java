import java.util.HashSet;
import java.util.Set;

public class Exemplo2Set {
	public static void main(String[] args) {

		Set<Cliente> lista = new HashSet<Cliente>();

		Cliente c1 = new Cliente(2, "matheus");
		Cliente c2 = new Cliente(3, "jessica");
		Cliente c3 = new Cliente(4, "vitor");
		Cliente c4 = new Cliente(5, "alex");
		Cliente c5 = new Cliente(2, "matheus");

		lista.add(c1);
		lista.add(c2);
		lista.add(c3);
		lista.add(c4);
		lista.add(c5);

		System.out.println(lista);

	}
}
