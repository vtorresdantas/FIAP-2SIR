package br.fiap.entidade;

import java.time.LocalDate;

// classe bean para repesentar um objeto pedido
public class Pedido {
	private Integer pedidoId;
	private String nomeContato;
	private String enderecoContato;
	private LocalDate data;
	
	public Integer getPedidoId() {
		return pedidoId;
	}
	public void setPedidoId(Integer pedidoId) {
		this.pedidoId = pedidoId;
	}
	public String getNomeContato() {
		return nomeContato;
	}
	public void setNomeContato(String nomeContato) {
		this.nomeContato = nomeContato;
	}
	public String getEnderecoContato() {
		return enderecoContato;
	}
	public void setEnderecoContato(String enderecoContato) {
		this.enderecoContato = enderecoContato;
	}
	public LocalDate getData() {
		return data;
	}
	public void setData(LocalDate data) {
		this.data = data;
	}	
}
