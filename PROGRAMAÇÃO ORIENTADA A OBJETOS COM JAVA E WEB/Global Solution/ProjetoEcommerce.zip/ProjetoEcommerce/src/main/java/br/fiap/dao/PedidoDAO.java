package br.fiap.dao;

import java.sql.Date;
import java.sql.SQLException;

import br.fiap.entidade.Pedido;
import br.fiap.entidade.Produto;

public class PedidoDAO extends DAO {

	/* método para inserir um pedido na base de dados. O método retorna true para saber
	 * se  pedido foi inserido ou não. Se o pedido não foi inserido, seus detalhes não serão
	 * inseridos na tabela detalhe pedido
	 */
	public boolean inserir(Pedido pedido) {
		boolean inseriu = false;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "insert into java_pedido values(pedido_sequence.nextval, ?, ?, ?)";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, pedido.getNomeContato());
			ps.setString(2, pedido.getEnderecoContato());
			ps.setDate(3, Date.valueOf(pedido.getData())); // converte a data para Data (sql)
			ps.execute();
			inseriu = true;
			ps.close();
			connection.close();
			conexao.desconectar();			
		} catch (SQLException e) {
			System.out.println("Erro ao inserir produto\n" + e);
		}
		
		return inseriu;
	}

	/* método para retornar o código do último pedido inserido. Esse
	 * código será inserido como chave estrangeira na tabela java_pedidodetalhe
	 */
	public Integer obterPedidoId() {
		Integer id = 0;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select max(pedido_id) from java_pedido";
		
		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			if(rs.next()) {
				id = rs.getInt("max(pedido_id)");
			}
			rs.close();
			ps.close();
			connection.close();
			conexao.desconectar();
		} catch (SQLException e) {
			System.out.println("erro ao pesquisar o último id inserido\n" + e);
		}
		
		
		return id;
	}
}
