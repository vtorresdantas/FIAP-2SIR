package br.fiap.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.entidade.Pedido;
import br.fiap.entidade.PedidoDetalhe;
import br.fiap.entidade.Produto;

public class PedidoDetalheDAO extends DAO {

	// método para inserir os detalhes do pedido no banco de dados
	public void inserir(PedidoDetalhe detalhe) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "insert into java_pedidodetalhe values(detalhe_sequence.nextval, ?, ?, ?, ?)";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, detalhe.getPedido().getPedidoId());
			ps.setInt(2, detalhe.getProduto().getProdutoId());
			ps.setInt(3, detalhe.getQuantidade());
			ps.setDouble(4, detalhe.getTotal());
			ps.execute();
			ps.close();
			connection.close();
			conexao.desconectar();
		} catch (SQLException e) {
			System.out.println("Erro ao inserir detalhes do pedido\n" + e);
		}
		
	}
	
	// método para retornar os detalhes do pedido
	public List<PedidoDetalhe> listar() {
		List<PedidoDetalhe> lista = new ArrayList<>();
		Pedido pedido;
		Produto produto;
		PedidoDetalhe detalhe;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select pe.nome_contato, pe.data, pr.nome, d.quantidade, d.total from"
				+ " java_pedido pe, java_produto pr, java_pedidodetalhe d where"
				+ " pe.pedido_id = d.pedido_id and d.produto_id = pr.produto_id";
		
		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				pedido = new Pedido();
				produto = new Produto();
				detalhe = new PedidoDetalhe();
				pedido.setNomeContato(rs.getString("nome_contato"));
				pedido.setData(rs.getDate("data").toLocalDate());
				produto.setNome(rs.getString("nome"));
				detalhe.setQuantidade(rs.getInt("quantidade"));
				detalhe.setTotal(rs.getDouble("total"));
				detalhe.setPedido(pedido);
				detalhe.setProduto(produto);
				lista.add(detalhe);
			}
			rs.close();
			ps.close();
			connection.close();
			conexao.desconectar();			
		} catch (SQLException e) {
			System.out.println("erro ao listar detalhes do pedido\n" + e);
		}
		
		
		return lista;
				
	}
}
