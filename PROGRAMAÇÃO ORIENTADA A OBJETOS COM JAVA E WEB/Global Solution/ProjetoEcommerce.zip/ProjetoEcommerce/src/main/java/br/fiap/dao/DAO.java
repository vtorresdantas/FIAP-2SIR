package br.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DAO {
	protected PreparedStatement ps;
	protected ResultSet rs;
	protected Connection connection;
	protected String sql;
}
