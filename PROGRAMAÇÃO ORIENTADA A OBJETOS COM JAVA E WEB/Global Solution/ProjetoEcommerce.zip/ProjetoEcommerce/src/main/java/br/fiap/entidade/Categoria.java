package br.fiap.entidade;

// classe bean para representar um objeto categoria
public class Categoria {
	private Integer categoriaId;
	private String categoria;
	
	public Integer getCategoriaId() {
		return categoriaId;
	}
	public void setCategoriaId(Integer categoriaId) {
		this.categoriaId = categoriaId;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}	
}
