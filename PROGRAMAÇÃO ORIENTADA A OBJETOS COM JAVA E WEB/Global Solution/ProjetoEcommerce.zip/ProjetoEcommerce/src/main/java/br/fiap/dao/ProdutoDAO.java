package br.fiap.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.entidade.Categoria;
import br.fiap.entidade.Produto;

public class ProdutoDAO extends DAO {
	
	// método para inserir um produto na base de dados
	public void inserir(Produto produto) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "insert into java_produto values(produto_sequence.nextval, ?, ?, ?, ?)";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, produto.getCategoria().getCategoriaId());
			ps.setString(2, produto.getNome());
			ps.setString(3, produto.getDescricao());
			ps.setDouble(4, produto.getPreco());
			ps.execute();
			ps.close();
			connection.close();
			conexao.desconectar();
		} catch (SQLException e) {
			System.out.println("Erro ao inserir produto\n" + e);
		}
	}
	
	// método para retornar a listagem dos produtos
	public List<Produto> listar() {
		List<Produto> lista = new ArrayList<>();
		Produto produto;
		Categoria categoria;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select p.produto_id, p.nome, p.descricao, p.preco, c.categoria from java_produto p, "
				+ "java_categoria c where p.categoria_id = c.categoria_id order by p.nome";
		
		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				categoria = new Categoria();
				produto = new Produto();
				categoria.setCategoria(rs.getString("categoria"));
				produto.setProdutoId(rs.getInt("produto_id"));
				produto.setNome(rs.getString("nome"));
				produto.setDescricao(rs.getString("descricao"));
				produto.setPreco(rs.getDouble("preco"));
				produto.setCategoria(categoria);
				lista.add(produto);
			}
			rs.close();
			ps.close();
			connection.close();
			conexao.desconectar();
		} catch (SQLException e) {
			System.out.println("Erro ao listar produtos\n" + e);
		}
		
		return lista;
	}
	
}
