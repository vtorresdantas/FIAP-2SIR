package br.fiap.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.entidade.Categoria;

public class CategoriaDAO extends DAO {
	
	// método para inserir uma categoria na base de dados
	public void inserir(String categoria) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "insert into java_categoria values(categoria_sequence.nextval, ?)";
		
		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, categoria);
			ps.execute();
			ps.close();
			connection.close();
			conexao.desconectar();
		} catch (SQLException e) {			
			System.out.println("Erro ao cadastrar categoria\n" + e);
		}
	}
	
	// método para retornar todas as categorias registradas na base de dados
	public List<Categoria> listar() {
		List<Categoria> lista = new ArrayList<>();
		Categoria categoria;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select * from java_categoria order by categoria";
		
		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while(rs.next()) {
				categoria = new Categoria();
				categoria.setCategoriaId(rs.getInt("categoria_id"));
				categoria.setCategoria(rs.getString("categoria"));
				lista.add(categoria);
			}
			ps.close();
			connection.close();
			conexao.desconectar();
		} catch (SQLException e) {			
			System.out.println("Erro ao listar categoria\n" + e);
		}
		return lista;
	}
	
	
}
