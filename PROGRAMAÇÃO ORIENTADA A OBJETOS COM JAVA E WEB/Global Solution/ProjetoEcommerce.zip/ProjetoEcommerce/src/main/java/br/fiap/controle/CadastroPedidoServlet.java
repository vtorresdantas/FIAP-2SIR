package br.fiap.controle;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.fiap.dao.PedidoDAO;
import br.fiap.dao.PedidoDetalheDAO;
import br.fiap.entidade.Categoria;
import br.fiap.entidade.Pedido;
import br.fiap.entidade.PedidoDetalhe;
import br.fiap.entidade.Produto;

/**
 * Servlet implementation class CadastroPedidoServlet
 */
@WebServlet("/cadastroPedido")
public class CadastroPedidoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
        
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PedidoDAO pedidoDao = new PedidoDAO();
		PedidoDetalheDAO detalheDao = new PedidoDetalheDAO();
		
		Produto produto = new Produto();
		Categoria categoria = new Categoria();
		Pedido pedido = new Pedido();
		PedidoDetalhe detalhe = new PedidoDetalhe();
		
		String nomeContato = request.getParameter("nomecontato");
		String enderecoContato = request.getParameter("enderecocontato");
		LocalDate data = formatarData(request.getParameter("data"));
		Integer produtoId = Integer.parseInt(request.getParameter("produto")); 
		int quantidade = Integer.parseInt(request.getParameter("quantidade"));
		double total = Double.parseDouble(request.getParameter("total"));
		
		// configura o objeto Pedido
		pedido.setNomeContato(nomeContato);
		pedido.setEnderecoContato(enderecoContato);
		pedido.setData(data);
		
		// insere o objeto pedido no banco de dados
		// método inserir pedido retornar true ou false --> para saber se inseriu ou não
		
		if(pedidoDao.inserir(pedido) ) {
			produto.setProdutoId(produtoId);
			pedido.setPedidoId(pedidoDao.obterPedidoId());
			detalhe.setPedido(pedido);
			detalhe.setProduto(produto);
			detalhe.setQuantidade(quantidade);
			detalhe.setTotal(total);
			detalheDao.inserir(detalhe);
		}
		
		response.sendRedirect("index.jsp");
		
	}
	
	// método para converter a data de String para LocalDate
	private LocalDate formatarData(String data) {
		String[] dataAux = data.split("-");
		String dataString = "";
		dataString = dataAux[2] + "/" + dataAux[1] + "/" + dataAux[0];
		
		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate localDate = LocalDate.parse(dataString, formato);
		return localDate;
	}

}
