package br.fiap.main;

import br.fiap.cargo.Cargo;
import br.fiap.funcionario.Funcionario;
import br.fiap.venda.Venda;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Funcionario funcionario = new Funcionario("vitor", 1000, Cargo.GERENTE);
		Venda venda = new Venda(funcionario, 1000.0);
		System.out.println(venda.calcularComissao());

	}

}
