package br.fiap.cargo;

public enum CargoEspecial {

	ATENDENTE("Atendente", 0.10), VENDEDOR("Vendedor", 0.15), GERENTE("Gerente", 0.20);

	private String nome;
	private Double comissao;

	private CargoEspecial(String nome, Double comissao) {
		this.nome = nome;
		this.comissao = comissao;
	}

	public String getNome() {
		return nome;
	}

	public Double getComissao() {
		return comissao;
	}

}
