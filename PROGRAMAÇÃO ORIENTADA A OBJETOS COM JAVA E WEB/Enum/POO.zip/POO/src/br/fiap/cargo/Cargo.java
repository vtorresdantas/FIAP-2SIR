package br.fiap.cargo;

public enum Cargo {

	ATENDENTE, VENDEDOR, GERENTE;

}
