package br.fiap.venda;

import br.fiap.cargo.Cargo;
import br.fiap.funcionario.Funcionario;

public class Venda {

	private Funcionario funcionario;
	private Double valor;

	public Venda(Funcionario funcionario, Double valor) {
		super();
		this.funcionario = funcionario;
		this.valor = valor;
	}

	public double calcularComissao() {

		double comissao = 0.0;
		Cargo cargo = funcionario.getCargo();

		if (cargo == Cargo.ATENDENTE) {
			comissao = valor * 0.10;
		} else {
			if (cargo == Cargo.VENDEDOR) {
				comissao = valor * 0.15 + 5;
			} else {
				comissao = valor * 0.20 + 10;
			}
		}

		return comissao;
	}

	public Funcionario getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	public Double getValor() {
		return valor;
	}

	public void setValor(Double valor) {
		this.valor = valor;
	}

	@Override
	public String toString() {
		String aux = "";

		aux += "Funcionario: " + funcionario.toString();
		aux += "Valor: " + valor;

		return aux;

	}

}
