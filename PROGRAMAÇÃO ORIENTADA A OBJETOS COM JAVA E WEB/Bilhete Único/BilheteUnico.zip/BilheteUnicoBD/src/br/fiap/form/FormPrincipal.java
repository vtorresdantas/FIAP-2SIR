package br.fiap.form;

import static javax.swing.JOptionPane.*;

import br.fiap.dao.UsuarioDAO;

import static java.lang.Integer.parseInt;

public class FormPrincipal {

	public void menuPrincipal() {
		UsuarioDAO usuarioDao = new UsuarioDAO();
		String opcao;

		do {
			opcao = showInputDialog("Digite sua senha ou CPF ou Sair");
			if (opcao.equalsIgnoreCase("admin")) {
				new FormAdmin().menuAdmin();
			} else if (!opcao.equalsIgnoreCase("sair")) {
				if (usuarioDao.pesquisarCpf(opcao)) {
					new FormUsuario().menuUsuario(opcao);
				} else {
					showMessageDialog(null, "Usuario nao cadastrado");
				}

			}

		} while (!opcao.equalsIgnoreCase("sair"));
	}

}
