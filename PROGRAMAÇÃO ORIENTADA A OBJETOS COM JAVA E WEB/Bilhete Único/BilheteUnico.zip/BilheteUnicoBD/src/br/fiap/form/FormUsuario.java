package br.fiap.form;

import static javax.swing.JOptionPane.*;

import br.fiap.dao.BilheteUnicoDAO;
import br.fiap.modelo.BilheteUnico;

import static java.lang.Integer.parseInt;
import static java.lang.Double.parseDouble;

public class FormUsuario {

	public void menuUsuario(String cpf) {

		int opcao;

		do {
			opcao = parseInt(showInputDialog(gerarMenuUsuario()));
			switch (opcao) {
			case 1:
				carregarBilhete(cpf);
				break;
			case 2:
				passarNaCatraca();
				break;
			case 3:
				consultarSaldo();
				break;
			}
		} while (opcao != 4);

	}

	private void consultarSaldo() {

	}

	private void passarNaCatraca() {

	}

	private void carregarBilhete(String cpf) {

		BilheteUnicoDAO bilheteDao = new BilheteUnicoDAO();
		BilheteUnico bilhete = bilheteDao.pesquisarCpf(cpf);

		Double valor = parseDouble(showInputDialog("Insira o valor de recarga"));

		bilheteDao.carregar(cpf, valor + bilhete.getSaldo());

	}

	private String gerarMenuUsuario() {
		String menu = "Escolha uma operacao:\n";
		menu += "1. Carregar Bilhete\n";
		menu += "2. Passar na Catraca\n";
		menu += "3. Consultar Saldo\n";
		menu += "4. Sair";
		return menu;
	}

}
