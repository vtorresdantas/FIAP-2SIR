package br.fiap.endereco.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.fiap.dao.EnderecoDAO;
import br.fiap.endereco.Endereco;

/**
 * Servlet implementation class AlterarContatoServelet
 */
@WebServlet("/alteraendereco")
public class AlterarEnderecoServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AlterarEnderecoServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		EnderecoDAO dao = new EnderecoDAO();
		Endereco endereco = new Endereco();
				
		
		endereco.setId(Integer.parseInt(request.getParameter("id")));
		endereco.setCep(Integer.parseInt(request.getParameter("cep")));
		endereco.setComplemento(request.getParameter("complemento"));
		endereco.setNumero(Integer.parseInt(request.getParameter("numero")));
		

		dao.alterar(endereco);
		
		
		// redireciona para index.jsp
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);	}

}
