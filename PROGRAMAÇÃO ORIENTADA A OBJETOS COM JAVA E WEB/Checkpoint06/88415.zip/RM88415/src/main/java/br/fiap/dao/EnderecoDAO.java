package br.fiap.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.endereco.Endereco;

public class EnderecoDAO extends DAO {

	public void inserir(Endereco endereco) {

		Conexao conexao = new Conexao();
		connection = conexao.conectar();

		sql = "INSERT INTO JAVA_ENDERECO VALUES(endereco_sequence.nextval, ?,?,?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, endereco.getCep());
			ps.setString(2, endereco.getComplemento());
			ps.setInt(3, endereco.getNumero());
			ps.execute();
			ps.close();
			conexao.desconectar();

		} catch (SQLException e) {
			System.out.println("Erro ao inserir na base de dados\n" + e);

		}
	}

	public Endereco pesquisar(int cep) {

		Endereco endereco = null;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "SELECT * FROM JAVA_ENDERECO WHERE id_endereco = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, cep);
			rs = ps.executeQuery();

			if (rs.next()) {
				endereco = new Endereco();
				endereco.setId(rs.getInt("id_endereco"));;
				endereco.setCep(cep);
				endereco.setComplemento(rs.getString("complemento"));
				endereco.setNumero(rs.getInt("numero"));

			}
			
			ps.close();
			conexao.desconectar();

		} catch (SQLException e) {

			System.out.println("Erro ao pesquisar endereco na base de dados\n" + e);

		}

		return endereco;
	}

	public List<Endereco> listar() {

		List<Endereco> lista = new ArrayList<Endereco>();
		Endereco endereco;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "SELECT * FROM JAVA_ENDERECO";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();

			// Percorre todos os registros encontrados

			while (rs.next()) {
				endereco = new Endereco();
				endereco.setId(rs.getInt("ID_ENDERECO"));
				endereco.setCep(rs.getInt("CEP"));
				endereco.setComplemento(rs.getString("COMPLEMENTO"));
				endereco.setNumero(rs.getInt("NUMERO"));
				// Adiciona o Endereco na lista
				lista.add(endereco);
			}
			ps.close();
			conexao.desconectar();

		} catch (SQLException e) {
			System.out.println("Erro ao listar Enderecos "+e);
		}

		return lista;
	}

	public void alterar(Endereco endereco) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "UPDATE JAVA_ENDERECO SET CEP = ?, COMPLEMENTO = ?, NUMERO = ? WHERE ID_ENDERECO = ?";
		
		try {
			ps = connection.prepareStatement(sql);

			ps.setInt(1, endereco.getCep());
			ps.setString(2, endereco.getComplemento());
			ps.setInt(3, endereco.getNumero());
			ps.setInt(4, endereco.getId());
			ps.execute();		
			ps.close();
			conexao.desconectar();
			

		} catch (SQLException e) {
			System.out.println("Erro ao alterar dados do Endereco na base de dados\n" + e);

		}

	}

}
