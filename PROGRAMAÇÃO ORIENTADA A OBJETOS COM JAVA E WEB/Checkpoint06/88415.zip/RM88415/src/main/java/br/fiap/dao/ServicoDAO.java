package br.fiap.dao;

import static javax.swing.JOptionPane.showMessageDialog;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.servico.Servico;

public class ServicoDAO extends DAO {

	public void inserir(Servico servico) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "INSERT INTO JAVA_SERVICO VALUES (servico_sequence.nextval, ?,?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, servico.getNome());
			ps.setString(2, servico.getDescricao());
			ps.execute();
			ps.close();

		} catch (SQLException e) {
			System.out.println("Erro ao inserir na base de dados\n" + e);

		}
	}

	public void alterar(Servico servico) {

		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "update java_servico set nome = ?, descricao = ? where id_servico = ?";
		
		try {
			ps = connection.prepareStatement(sql);

			ps.setString(1, servico.getNome());
			ps.setString(2, servico.getDescricao());
			ps.setInt(3, servico.getId());
			ps.execute();
			ps.close();
			conexao.desconectar();

		} catch (SQLException e) {
			System.out.println("Erro ao alterar dados do Servico na base de dados\n" + e);

		}

	}

	public Servico pesquisar(int id) {

		Servico servico = null;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "SELECT * FROM JAVA_SERVICO WHERE id_servico = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();

			if (rs.next()) {
				id = rs.getInt("ID_SERVICO");
				servico = new Servico();
				servico.setNome(rs.getString("NOME"));
				servico.setDescricao(rs.getString("DESCRICAO"));

			}

		
		} catch (SQLException e) {

			showMessageDialog(null, "Erro ao consultar servico no banco de dados\n" + e);

		}

		return servico;
	}

	public List<Servico> listar() {
		List<Servico> lista = new ArrayList<Servico>();
		Servico servico;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();

		sql = "SELECT * FROM JAVA_SERVICO";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();

			// Percorre todos os registros encontrados

			while (rs.next()) {
				servico = new Servico();
				servico.setId(rs.getInt("ID_SERVICO"));
				servico.setNome(rs.getString("NOME"));
				servico.setDescricao(rs.getString("DESCRICAO"));

				// Adiciona o Endereco na lista
				lista.add(servico);

			}

			ps.close();
			conexao.desconectar();
		} catch (SQLException e) {
			System.out.println("Erro ao LISTAR SERVICOS \n" + e);
		}

		return lista;
	}

}
