package br.fiap.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.contato.Contato;

public class ContatoDAO extends DAO {

	public void inserir(Contato contato) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "insert into java_contato values(contato_sequence.nextval, ?,?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, contato.getTelefone());
			ps.setString(2, contato.getEmail());
			ps.execute();

			ps.close();
			conexao.desconectar();

		} catch (SQLException e) {
			System.out.println("Erro ao inserir na base de dados\n" + e);
		}
	}

	// m�todo para pesquisar um contato pelo email
	public Contato pesquisar(String email) {
		Contato contato = null;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select * from java_contato where EMAIL = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, email);
			rs = ps.executeQuery();
			if (rs.next()) {
				contato = new Contato();

				contato.setId(rs.getInt("ID_CONTATO"));
				contato.setTelefone(rs.getString("telefone"));
				contato.setEmail(email);
			}
			ps.close();
			conexao.desconectar();

		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar contato na base de dados\n" + e);
		}
		return contato;
	}

	// m�todo para pesquisar um contato pelo id
	public Contato pesquisarId(Integer id) {
		Contato contato = null;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select * from java_contato where ID_CONTATO = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				contato = new Contato();

				contato.setId(id);
				contato.setTelefone(rs.getString("telefone"));
				contato.setEmail(rs.getString("email"));
			}
			ps.close();
			conexao.desconectar();
		} catch (SQLException e) {
			System.out.println("Erro ao pesquisar contato pelo id\n" + e);
		}
		return contato;
	}

	// m�todo para retornar uma lista de contatos
	public List<Contato> listar() {
		List<Contato> lista = new ArrayList<Contato>();
		Contato contato;
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "select * from java_contato";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				contato = new Contato();
				contato.setId(rs.getInt("id_contato"));
				contato.setTelefone(rs.getString("telefone"));
				contato.setEmail(rs.getString("email"));
				lista.add(contato);
			}
			ps.close();
			conexao.desconectar();
		} catch (SQLException e) {
			System.out.println("Erro ao LISTAR \n" + e);
		}

		return lista;
	}

	// m�todo para alterar os dados de um contato
	public void alterar(Contato contato) {
		Conexao conexao = new Conexao();
		connection = conexao.conectar();
		sql = "update java_contato set email = ?, telefone = ?  where id_contato = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, contato.getEmail());
			ps.setString(2, contato.getTelefone());
			ps.setInt(3, contato.getId());
			ps.execute();
			ps.close();
			conexao.desconectar();
		} catch (SQLException e) {
			System.out.println("Erro ao alterar dados do contato na base de dados\n" + e);
		}
	}
}
