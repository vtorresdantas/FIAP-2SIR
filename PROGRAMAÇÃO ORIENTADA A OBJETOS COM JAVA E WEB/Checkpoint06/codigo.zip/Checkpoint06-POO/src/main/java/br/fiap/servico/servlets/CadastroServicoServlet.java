package br.fiap.servico.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.fiap.dao.ServicoDAO;
import br.fiap.servico.Servico;

/**
 * Servlet implementation class CadastroContatoServlet
 */
@WebServlet("/cadastroservico")
public class CadastroServicoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CadastroServicoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		ServicoDAO dao = new ServicoDAO();
		Servico servico = new Servico();
		
		
		
		servico.setNome(request.getParameter("nome"));
		servico.setDescricao(request.getParameter("descricao"));
		
		dao.inserir(servico);	
		
		// redireciona para index.jsp
		RequestDispatcher dispatcher = request.getRequestDispatcher("index.jsp");
		dispatcher.forward(request, response);
		
	}

}
