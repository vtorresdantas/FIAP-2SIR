package br.fiap.servico.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.fiap.dao.ServicoDAO;
import br.fiap.servico.Servico;

/**
 * Servlet implementation class ListaContatoServelet
 */
@WebServlet("/listaservico")
public class ListaServicoServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ServicoDAO dao = new ServicoDAO();
		Servico servico;

		int id = Integer.parseInt(request.getParameter("id"));

		servico = dao.pesquisar(id);

		if (servico != null) {
			RequestDispatcher dispatcher = request.getRequestDispatcher("/form/ListarServico.jsp");
			dispatcher.forward(request, response);
		}
	}

}
