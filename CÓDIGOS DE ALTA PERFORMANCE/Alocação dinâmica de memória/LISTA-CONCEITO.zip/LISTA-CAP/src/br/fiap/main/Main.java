package br.fiap.main;

import br.fiap.arvore.Lista;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Lista lista = new Lista();
		lista.insere(1);
		lista.insere(2);

	}

}
