package br.fiap.arvore;

public class Lista {

	private class NO {
		int dado;
		NO prox;
	}

	NO lista = null;

	public void insere(int valor) {
		NO novo = new NO();
		novo.dado = valor;
		novo.prox = lista;
		System.out.println("novo= " + novo + " dado= " + novo.dado + " prox= " + novo.prox);
		lista = novo;
		System.out.println("LISTA= " + lista + "\n");
	}

}
