package arvore;

public class ABBint {

	private class ARVORE {
		int dado;
		ARVORE esq, dir;
	}

	public ARVORE raiz = null;

	public ARVORE inserir(ARVORE p, int info) {
		// insere elemento em uma ABB
		if (p == null) {
			p = new ARVORE();
			p.dado = info;
			p.esq = null;
			p.dir = null;
		} else if (info < p.dado)
			p.esq = inserir(p.esq, info);
		else
			p.dir = inserir(p.dir, info);
		return p;
	}

	public void listaEmOrdem(ARVORE p) {
		if (p != null) {
			listaEmOrdem(p.esq);
			System.out.println("Dado : " + p.dado);
			listaEmOrdem(p.dir);
		}
	}

	// Exercicio 01 - Vitor Ideia Git
	public int contaNos(ARVORE atual) {
		if (atual == null)
			return 0;
		else
			return (1 + contaNos(atual.esq) + contaNos(atual.dir));
	}

	// Ex 01 - Prof
	public int contaNos02(ARVORE p, int cont) {
		if (p != null) {
			cont++;
			cont = contaNos02(p.esq, cont);
			cont = contaNos02(p.dir, cont);
		}
		return cont;
	}

	// Exercicio 02 - Vitor Git
	public ARVORE buscar(int chave) {
		if (raiz == null)
			return null;
		ARVORE novo = raiz;
		while (novo.dado != chave) {
			if (chave < novo.dado)
				novo = novo.esq;
			else
				novo = novo.dir;
			if (novo == null)
				return null;
		}
		return novo;
	}

	public boolean consulta(ARVORE p, int info) {

		if (p != null) {
			if (p.dado == info)
				return true;
			else if (info < p.dado)
				return (consulta(p.esq, info));
			else
				return (consulta(p.dir, info));

		}

		return false;

	}

	public ARVORE removeValor(ARVORE p, int info) {
		if (p != null) {
			if (info == p.dado) {
				if (p.esq == null && p.dir == null) // nó a ser removido é nó folha
					return null;
				if (p.esq == null) { // se não há sub-árvore esquerda o ponteiro passa apontar para a sub-árvore
										// direita
					return p.dir;
				} else {
					if (p.dir == null) { // se não há sub-árvore direita o ponteiro passa apontar para a sub-árvore
											// esquerda
						return p.esq;
					} else { /*
								 * o nó a ser retirado possui sub-arvore esquerda e direita, então o nó que será
								 * retirado deve-se encontrar o menor valor na sub-árvore á direita
								 */
						ARVORE aux, ref;
						ref = p.dir;
						aux = p.dir;
						while (aux.esq != null)
							aux = aux.esq;
						aux.esq = p.esq;
						return ref;
					}
				}
			} else { // procura dado a ser removido na ABBr
				if (info < p.dado)
					p.esq = removeValor(p.esq, info);
				else
					p.dir = removeValor(p.dir, info);
			}
		}
		return p;
	}
}
