package aplicacao;

import java.util.Scanner;

import arvore.ABBint;

public class Main {

	public static void main(String[] args) {

		ABBint abb = new ABBint();

		Scanner le = new Scanner(System.in);
		int opcao;

		do {
			System.out.println("0 - Encerrar");
			System.out.println("1 - Inserir");
			System.out.println("2 - Lista em Ordem Crescente");
			System.out.println("3 - Numero de nos ");
			System.out.println("4 - Consultar");
			System.out.println("5 - Listar ");
			System.out.println("");
			opcao = le.nextInt();
			switch (opcao) {
			case 0:
				System.out.println("Encerrado");
				break;
			case 1:
				System.out.print("Informe valor a ser inserido: ");
				int info = le.nextInt();
				abb.raiz = abb.inserir(abb.raiz, info);
				break;
			case 2:
				abb.listaEmOrdem(abb.raiz);
				break;
			case 3:
				System.out.println("Contagem de nós: " + abb.contaNos(abb.raiz));
				break;
			case 4:
				System.out.println("Insira o valor a ser consultado");
				info = le.nextInt();
				if (abb.consulta(abb.raiz, info))
					System.out.println(" Valor está presente na ABB");
				else
					System.out.println(" Valor não encontrado");
				break;

			default:
				System.out.println("Opcão inválida");
			}

		} while (opcao != 0);
		le.close();
	}

}
