package exercicio02;

import java.util.Scanner;

import listas.ListaAlunos;

public abstract class PlanilhaAlunos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ListaAlunos turma = new ListaAlunos();
		Scanner le = new Scanner(System.in);
		int opcao;
		do {
			System.out.println("0- Sair");
			System.out.println("1- Insere aluno");
			System.out.println("2- Remove aluno");
			System.out.println("3- Pesquisar aluno");
			opcao = le.nextInt();

			switch (opcao) {
			case 0:
				System.out.println("Encerrando o programa");
				break;
			case 1:
				System.out.println("RM: ");
				int rm = le.nextInt();
				System.out.println("M�dia: ");
				double media = le.nextDouble();
				Aluno aluno = new Aluno(rm, media);
				turma.insere(aluno);
				turma.show();
				break;
			case 2:
				System.out.println("RM do aluno a ser removido da lista");
				rm = le.nextInt();
				turma.remove(rm);
				turma.show();
				break;
			case 3:
				System.out.println("RM do aluno a ser pesquisado");
				rm = le.nextInt();
				turma.select(rm);
				turma.show();
				break;
			default:
				System.out.println("Op��o inv�lida");
			}

		} while (opcao != 0);
		le.close();
	}

}
