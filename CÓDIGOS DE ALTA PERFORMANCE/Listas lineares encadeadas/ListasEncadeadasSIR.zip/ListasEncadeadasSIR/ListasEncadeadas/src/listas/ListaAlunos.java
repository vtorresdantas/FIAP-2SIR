package listas;

import exercicio02.Aluno;

public class ListaAlunos {

	private class NO {
		Aluno dado;
		NO prox;
	}

	NO lista = null;

	public void insere(Aluno elem) {
		NO novo = new NO();
		novo.dado = elem;
		if (lista == null) {
			novo.prox = null;
			lista = novo;
		} else if (novo.dado.getRm() < lista.dado.getRm()) { // Insere como 1o da lista
			novo.prox = lista;
			lista = novo;
		} else { // insere a partir do 2o elemento
			NO aux = lista;
			boolean achou = false;
			while (aux.prox != null && !achou) {
				if (aux.prox.dado.getRm() < novo.dado.getRm())
					aux = aux.prox;
				else
					achou = true;
			}
			novo.prox = aux.prox;
			aux.prox = novo;
		}
	}

	public void show() {
		NO aux = lista;
		while (aux != null) {
			System.out.print(aux.dado + "\t");
			aux = aux.prox;
		}
		System.out.println();
	}

	public void remove(int rm) {
		if (lista != null) {
			if (rm == lista.dado.getRm())
				lista = lista.prox;
			else {
				NO aux = lista;
				boolean achou = false;
				while (aux.prox != null && !achou) {
					if (aux.prox.dado.getRm() == rm)
						achou = true;
					else
						aux = aux.prox;
				}
				if (achou)
					aux.prox = aux.prox.prox;
				else
					System.out.println("Valor n�o foi encontrado na lista");
			}
		} else
			System.out.println("Lista est� vazia");
	}

	public double select(int rm) {

		NO aux = lista;
		double media = -1;
		while (aux != null && media == -1) {
			if (rm == aux.dado.getRm()) {
				return aux.dado.getMedia();
			}
			aux = aux.prox;
		}

		return media;
	}

}
