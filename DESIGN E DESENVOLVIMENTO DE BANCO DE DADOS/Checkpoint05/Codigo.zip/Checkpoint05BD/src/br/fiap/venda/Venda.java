package br.fiap.venda;

public class Venda {

	private int id;
	private String data;
	private String vendedor;

	public Venda(int id, String data, String vendedor) {
		super();
		this.id = id;
		this.data = data;
		this.vendedor = vendedor;
	}

	public Venda(String data, String vendedor) {
		super();
		this.data = data;
		this.vendedor = vendedor;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getVendedor() {
		return vendedor;
	}

	public void setVendedor(String vendedor) {
		this.vendedor = vendedor;
	}

	@Override
	public String toString() {
		String aux = "";

		aux += "Id:" + id + "\n";
		aux += "Data: " + data + "\n";
		aux += "Vendedor: " + vendedor + "\n";

		return aux;
	}

}
