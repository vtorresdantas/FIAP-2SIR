package br.fiap.menu;

import static java.lang.Integer.parseInt;
import static java.lang.Double.parseDouble;
import static javax.swing.JOptionPane.showInputDialog;
import static javax.swing.JOptionPane.showMessageDialog;

import br.fiap.cliente.Cliente;
import br.fiap.dao.ClienteDAO;
import br.fiap.dao.ProdutoDAO;
import br.fiap.dao.VendaDAO;
import br.fiap.produto.Produto;
import br.fiap.venda.Venda;

public class Controle {

	ClienteDAO clienteDAO = new ClienteDAO();
	ProdutoDAO produtoDAO = new ProdutoDAO();
	VendaDAO vendaDAO = new VendaDAO();

	public void menu() {
		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(gerarMenu()));
				if (opcao < 1 || opcao > 4) {
					showMessageDialog(null, "Opcao invalida");
				} else {
					switch (opcao) {
					case 1:
						menuCliente();
						break;
					case 2:
						menuProduto();
						break;
					case 3:
						menuVenda();
						break;
					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A opcao deve ser um numero valido");
			}
		} while (opcao != 4);
	}

	private String gerarMenu() {
		String msg = "Escolha uma opcao\n";
		msg += "1. Menu do cliente\n";
		msg += "2. Menu do produto\n";
		msg += "3. Menu da venda\n";
		msg += "4. Finalizar";
		return msg;
	}

	public void menuCliente() {

		String msg = "Escolha uma opcao\n";
		msg += "1. Cadastrar novo cliente\n";
		msg += "2. Consultar dados do cliente\n";
		msg += "3. Editar nome do cliente\n";
		msg += "4. Listar dados de todos os clientes\n";
		msg += "5. Remover dados do cliente\n";
		msg += "6. Sair\n";

		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(msg));
				if (opcao < 1 || opcao > 6) {
					showMessageDialog(null, "Opcao invalida");
				} else {
					switch (opcao) {
					case 1:
						int id = parseInt(showInputDialog("Digite o id:"));
						String nome = showInputDialog("Digite o nome:");
						String email = showInputDialog("Digite o email:");
						String cpf = showInputDialog("Digite o cpf");
						Cliente cliente = new Cliente(id, nome, email, cpf);
						clienteDAO.inserir(cliente);
						break;
					case 2:
						cpf = showInputDialog("Digite o cpf a ser pesquisado:");
						clienteDAO.pesquisar(cpf);
						break;
					case 3:
						cpf = showInputDialog("Digite o cpf a ser alterado:");
						nome = showInputDialog("Digite o novo nome a ser alterado: ");
						cliente = new Cliente(nome, cpf);
						clienteDAO.atualizar(cliente);
						break;
					case 4:
						clienteDAO.listar();
						break;
					case 5:
						cpf = showInputDialog("Digite o cpf a ser exclu�do:");
						clienteDAO.remover(cpf);
						break;

					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A opcao deve ser um numero valido");
			}
		} while (opcao != 6);

	}

	public void menuProduto() {

		String msg = "Escolha uma opcao\n";
		msg += "1. Cadastrar novo produto\n";
		msg += "2. Consultar dados de produto\n";
		msg += "3. Editar nome do produto\n";
		msg += "4. Listar dados de todos os produtos\n";
		msg += "5. Remover dados do produtos\n";
		msg += "6. Sair\n";

		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(msg));
				if (opcao < 1 || opcao > 6) {
					showMessageDialog(null, "Opcao invalida");
				} else {
					switch (opcao) {
					case 1:
						int id = parseInt(showInputDialog("Digite o id do produto:"));
						String nome = showInputDialog("Digite o nome do produto:");
						double valor = parseDouble(showInputDialog("Digite o valor do produto:"));
						String descricao = showInputDialog("Digite a descricao do produto");
						Produto produto = new Produto(id, nome, valor, descricao);
						produtoDAO.inserir(produto);
						break;
					case 2:
						nome = showInputDialog("Digite o nome do produto a ser pesquisado:");
						produtoDAO.pesquisar(nome);
						break;
					case 3:
						nome = showInputDialog("Digite o nome do produto a ser alterado:");
						valor = parseDouble(showInputDialog("Digite o novo valor do produto:"));
						produto = new Produto(nome, valor);
						produtoDAO.atualizar(produto);
						break;
					case 4:
						produtoDAO.listar();
						break;
					case 5:
						nome = showInputDialog("Digite o nome do produto a ser removido:");
						produtoDAO.remover(nome);
						break;
					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A opcao deve ser um numero valido");
			}
		} while (opcao != 6);

	}

	public void menuVenda() {

		String msg = "Escolha uma opcao\n";
		msg += "1. Cadastrar nova venda\n";
		msg += "2. Consultar dados de venda\n";
		msg += "3. Editar dados da venda\n";
		msg += "4. Listar dados de todas as vendas\n";
		msg += "5. Remover dados de venda\n";
		msg += "6. Sair\n";

		int opcao = 0;

		do {
			try {
				opcao = parseInt(showInputDialog(msg));
				if (opcao < 1 || opcao > 6) {
					showMessageDialog(null, "Opcao invalida");
				} else {
					switch (opcao) {
					case 1:
						int id = parseInt(showInputDialog("Digite o id:"));
						String data = showInputDialog("Digite a data:");
						String vendedor = showInputDialog("Digite o nome do vendedor:");
						Venda venda = new Venda(id, data, vendedor);
						vendaDAO.inserir(venda);
						break;
					case 2:
						vendedor = showInputDialog("Digite o nome do vendedor a ser pesquisado:");
						vendaDAO.pesquisar(vendedor);
						break;
					case 3:
						vendedor = showInputDialog("Digite o nome do vendedor a ser alterado:");
						data = showInputDialog("Digite a nova data a ser alterado: ");
						venda = new Venda(data, vendedor);
						vendaDAO.atualizar(venda);
						break;
					case 4:
						vendaDAO.listar();
						break;
					case 5:
						vendedor = showInputDialog("Digite o nome do vendedor a ser removido:");
						vendaDAO.remover(vendedor);
						break;
					}
				}
			} catch (NumberFormatException e) {
				showMessageDialog(null, "A opcao deve ser um numero valido");
			}
		} while (opcao != 6);

	}

}
