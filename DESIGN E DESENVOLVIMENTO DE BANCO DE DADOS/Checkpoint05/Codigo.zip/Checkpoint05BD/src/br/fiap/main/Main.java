package br.fiap.main;

import br.fiap.menu.Controle;

public class Main {

	public static void main(String[] args) {
		
		Controle controle = new Controle();
		controle.menu();
		

	}

}
