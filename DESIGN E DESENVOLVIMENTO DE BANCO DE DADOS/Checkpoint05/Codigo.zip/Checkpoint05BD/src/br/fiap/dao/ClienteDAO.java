package br.fiap.dao;

import static javax.swing.JOptionPane.showMessageDialog;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.cliente.Cliente;
import br.fiap.conexao.Conexao;

public class ClienteDAO {

	// variaveis para manipulacao de dados
	private Connection connection; // armazena a conexao com o banco de dados
	private PreparedStatement ps; // configura e executa o sql
	private ResultSet rs; // recebe os dados do banco
	private String sql; // escrever o comando SQL

	public ClienteDAO() {
		connection = new Conexao().conectar();
	}

	public void inserir(Cliente cliente) {

		sql = "INSERT INTO JAVA_CLIENTE(id_cliente, nome, email, cpf) VALUES (?,?,?,?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, cliente.getId());
			ps.setString(2, cliente.getNome());
			ps.setString(3, cliente.getEmail());
			ps.setString(4, cliente.getCpf());
			ps.execute();

			showMessageDialog(null, "Cliente cadastrado");

		} catch (SQLException e) {

			showMessageDialog(null, "Erro ao inserir no banco de dados\n" + e);

		}
	}

	public void remover(String cpf) {

		sql = "DELETE FROM JAVA_CLIENTE WHERE cpf = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, cpf);
			ps.executeUpdate();

			showMessageDialog(null, "Cliente removido");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao remover registro no banco de dados\n" + e);

		}
	}

	public Cliente pesquisar(String cpf) {

		Cliente cliente = null;

		sql = "SELECT * FROM JAVA_CLIENTE WHERE cpf = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, cpf);
			rs = ps.executeQuery();

			if (rs.next()) {
				int id = rs.getInt("ID_CLIENTE");
				String nome = rs.getString("NOME");
				String email = rs.getString("EMAIL");
				cpf = rs.getString("CPF");

				cliente = new Cliente(id, nome, email, cpf);

			}

			showMessageDialog(null, cliente.toString());

		} catch (SQLException e) {

			showMessageDialog(null, "Erro ao consultar no banco de dados\n" + e);

		}

		return cliente;
	}

	public List<Cliente> listar() {

		List<Cliente> lista = new ArrayList<Cliente>();

		sql = "SELECT * FROM JAVA_CLIENTE";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();

			// Percorre todos os registros encontrados

			while (rs.next()) {

				int id = rs.getInt("ID_CLIENTE");
				String nome = rs.getString("NOME");
				String email = rs.getString("EMAIL");
				String cpf = rs.getString("CPF");

				// Cria um objeto Cliente com as informacoes encontradas
				Cliente cliente = new Cliente(id, nome, email, cpf);
				// Adiciona o Cliente na lista
				lista.add(cliente);

			}

			for (Cliente item : lista) {
				showMessageDialog(null, item.toString() + "\n");
			}

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao listar os registros no banco de dados\n" + e);

		}

		return lista;
	}

	public void atualizar(Cliente cliente) {

		sql = "UPDATE JAVA_CLIENTE SET NOME = ? WHERE CPF = ?";

		try {
			ps = connection.prepareStatement(sql);

			ps.setString(1, cliente.getNome());
			ps.setString(2, cliente.getCpf());
			ps.executeUpdate();

			showMessageDialog(null, "Cliente atualizado");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao atualizar registro no banco de dados\n" + e);

		}

	}

}
