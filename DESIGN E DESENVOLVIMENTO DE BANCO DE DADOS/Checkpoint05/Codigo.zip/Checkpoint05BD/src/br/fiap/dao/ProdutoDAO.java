package br.fiap.dao;

import static javax.swing.JOptionPane.showMessageDialog;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.produto.Produto;

public class ProdutoDAO {
	
	// variaveis para manipulacao de dados
	private Connection connection; // armazena a conexao com o banco de dados
	private PreparedStatement ps; // configura e executa o sql
	private ResultSet rs; // recebe os dados do banco
	private String sql; // escrever o comando SQL

	public ProdutoDAO() {
		connection = new Conexao().conectar();
	}

	public void inserir(Produto produto) {

		sql = "INSERT INTO JAVA_PRODUTO(id_produto, nome, valor, descricao) VALUES (?,?,?,?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, produto.getId());
			ps.setString(2, produto.getNome());
			ps.setDouble(3, produto.getValor());
			ps.setString(4, produto.getDescricao());
			ps.execute();

			showMessageDialog(null, "Produto cadastrado");

		} catch (SQLException e) {

			showMessageDialog(null, "Erro ao inserir no banco de dados\n" + e);

		}
	}

	public void remover(String nome) {

		sql = "DELETE FROM JAVA_PRODUTO WHERE nome = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, nome);
			ps.executeUpdate();

			showMessageDialog(null, "Produto removido");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao remover registro no banco de dados\n" + e);

		}
	}

	public Produto pesquisar(String nome) {

		Produto produto = null;

		sql = "SELECT * FROM JAVA_PRODUTO WHERE nome = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, nome);
			rs = ps.executeQuery();

			if (rs.next()) {
				int id = rs.getInt("ID_PRODUTO");
				nome = rs.getString("NOME");
				double valor = rs.getDouble("VALOR");
				String descricao = rs.getString("DESCRICAO");

				produto = new Produto(id, nome, valor, descricao);

			}

			showMessageDialog(null, produto.toString());

		} catch (SQLException e) {

			showMessageDialog(null, "Erro ao consultar no banco de dados\n" + e);

		}

		return produto;
	}

	public List<Produto> listar() {

		List<Produto> lista = new ArrayList<Produto>();

		sql = "SELECT * FROM JAVA_PRODUTO";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();

			// Percorre todos os registros encontrados

			while (rs.next()) {

				int id = rs.getInt("ID_PRODUTO");
				String nome = rs.getString("NOME");
				double valor = rs.getDouble("VALOR");
				String descricao = rs.getString("DESCRICAO");

				// Cria um objeto Produto com as informacoes encontradas
				Produto produto = new Produto(id, nome, valor, descricao);
				// Adiciona o Produto na lista
				lista.add(produto);

			}

			for (Produto item : lista) {
				showMessageDialog(null, item.toString() + "\n");
			}

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao listar os registros no banco de dados\n" + e);

		}

		return lista;
	}

	public void atualizar(Produto produto) {

		sql = "UPDATE JAVA_PRODUTO SET VALOR = ? WHERE NOME = ?";

		try {
			ps = connection.prepareStatement(sql);

			ps.setDouble(1, produto.getValor());
			ps.setString(2, produto.getNome());
			ps.executeUpdate();

			showMessageDialog(null, "Produto atualizado");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao atualizar registro no banco de dados\n" + e);

		}
	}

}
