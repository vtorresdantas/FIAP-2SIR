package br.fiap.dao;

import static javax.swing.JOptionPane.showMessageDialog;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.fiap.conexao.Conexao;
import br.fiap.venda.Venda;

public class VendaDAO {

	// variaveis para manipulacao de dados
	private Connection connection; // armazena a conexao com o banco de dados
	private PreparedStatement ps; // configura e executa o sql
	private ResultSet rs; // recebe os dados do banco
	private String sql; // escrever o comando SQL

	public VendaDAO() {
		connection = new Conexao().conectar();
	}

	public void inserir(Venda venda) {

		sql = "INSERT INTO JAVA_VENDA(id_venda, data_venda, nome_vendedor) VALUES (?,?,?)";

		try {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, venda.getId());
			ps.setString(2, venda.getData());
			ps.setString(3, venda.getVendedor());
			ps.execute();

			showMessageDialog(null, "Venda cadastrada");

		} catch (SQLException e) {

			showMessageDialog(null, "Erro ao inserir no banco de dados\n" + e);

		}
	}

	public void remover(String vendedor) {

		sql = "DELETE FROM JAVA_VENDA WHERE nome_vendedor = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, vendedor);
			ps.executeUpdate();

			showMessageDialog(null, "Venda removida");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao remover registro no banco de dados\n" + e);

		}
	}

	public Venda pesquisar(String vendedor) {

		Venda venda = null;

		sql = "SELECT * FROM JAVA_VENDA WHERE nome_vendedor = ?";

		try {
			ps = connection.prepareStatement(sql);
			ps.setString(1, vendedor);
			rs = ps.executeQuery();

			if (rs.next()) {
				int id = rs.getInt("ID_VENDA");
				String data = rs.getString("DATA_VENDA");
				vendedor = rs.getString("NOME_VENDEDOR");

				venda = new Venda(id, data, vendedor);

			}

			showMessageDialog(null, venda.toString());

		} catch (SQLException e) {

			showMessageDialog(null, "Erro ao consultar no banco de dados\n" + e);

		}

		return venda;
	}

	public List<Venda> listar() {

		List<Venda> lista = new ArrayList<Venda>();

		sql = "SELECT * FROM JAVA_VENDA";

		try {
			ps = connection.prepareStatement(sql);
			rs = ps.executeQuery();

			// Percorre todos os registros encontrados

			while (rs.next()) {

				int id = rs.getInt("ID_VENDA");
				String data = rs.getString("DATA_VENDA");
				String vendedor = rs.getString("NOME_VENDEDOR");

				// Cria um objeto Venda com as informacoes encontradas
				Venda venda = new Venda(id, data, vendedor);
				// Adiciona o Venda na lista
				lista.add(venda);

			}

			for (Venda item : lista) {
				showMessageDialog(null, item.toString() + "\n");
			}

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao listar os registros no banco de dados\n" + e);

		}

		return lista;
	}

	public void atualizar(Venda venda) {

		sql = "UPDATE JAVA_VENDA SET DATA_VENDA = ? WHERE NOME_VENDEDOR = ?";

		try {
			ps = connection.prepareStatement(sql);

			ps.setString(1, venda.getData());
			ps.setString(2, venda.getVendedor());
			ps.executeUpdate();

			showMessageDialog(null, "Venda atualizada");

		} catch (SQLException e) {
			showMessageDialog(null, "Erro ao atualizar registro no banco de dados\n" + e);

		}
	}

}
